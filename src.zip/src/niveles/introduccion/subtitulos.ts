/**
 * Líneas simultáneas:	    1-2
 * Caracteres por línea:	  30-35
 * Caracteres por segundo:	10-12
 * Palabras por subtítulo:	4-8
 */

import type { Subtitulo } from '../../componentes_reutilizables/Gestor_subtitulos/Gestor_subtitulos'

export const transcripciones: Subtitulo[] = [
  { tiempo: 0,   texto: '¡Muy buenas! Yo soy ROCIO.' },
  { tiempo: 2,   texto: 'Voy a acompañarte mientras aprendemos' },
  { tiempo: 3.8, texto: 'cómo funciona un ordenador' },
  { tiempo: 5.1, texto: 'desde el principio y sin ninguna prisa.' },
  { tiempo: 7.8, texto: 'Iremos paso a paso.' },
]